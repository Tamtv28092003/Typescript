import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
    cloud_name: "ecommercer2021",
    api_key: "626155946999554",
    api_secret: "7VZ2gYWaR0ZWKGfd55uBPIjEnso",
});

export default cloudinary;